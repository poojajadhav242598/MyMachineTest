package com.example.sqliteexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends ArrayAdapter<Info_db> {
    //the tutorial list that will be displayed
    private List<Info_db> tutorialList;
    private Bitmap bitmap;
    private Context mCtx;
    //here we are getting the tutoriallist and context
    //so while creating the object of this adapter class we need to give tutoriallist and context
    public MyAdapter(List<Info_db> tutorialList, Context mCtx) {
        super(mCtx, R.layout.list_item, tutorialList);
        this.tutorialList = tutorialList;
        this.mCtx = mCtx;
    }

    //this method will return the list item
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //getting the layoutinflater
        ViewHolder holder;
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        convertView = inflater.inflate(R.layout.list_item, null, true);
        holder = new ViewHolder();
        //getting text views
        holder.textViewName = convertView.findViewById(R.id.textViewName);
       holder.textDescription = convertView.findViewById(R.id.textViewImageUrl);
        holder.imageView = convertView.findViewById(R.id.imageView);
        holder.lnrLayout = convertView.findViewById(R.id.lnrLayout);


        convertView.setTag(holder);
        //Getting the tutorial for the specified position
        Info_db tutorial = tutorialList.get(position);
        String imageUrl = tutorial.getImageUrl();
        String tutorialDescription = tutorial.getDescription();
        String tutorialTitle = tutorial.getName();

        holder.textViewName.setText(tutorialTitle);
        holder.textDescription.setText(tutorialDescription);

        if (holder.imageView != null) {
            /*-------------fatching image------------*/;
            new ImageDownloaderTask(holder.imageView).execute(imageUrl);
        }
        holder.imageView.setImageBitmap(bitmap);
        return convertView;
    }
//    public void removeItem(int position) {
//        data.remove(position);
//        notifyItemRemoved(position);
//    }

//    public void restoreItem(String item, int position) {
//        data.add(position, item);
//        notifyItemInserted(position);
//    }
    static class ViewHolder {
        TextView textViewName;
        TextView textDescription;
        ImageView imageView;
        LinearLayout lnrLayout;
    }
}
